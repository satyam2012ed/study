package com.capgemini.tcc.dao;
/*
 * author by Pritam Bhattcharjee
 * Last modified on 17 Aug 2018
 * */
public interface IQueryMapper {
public static final String INSERT_QUERY="INSERT INTO Patient VALUES(Patient_Id_Seq.NEXTVAL,?,?,?,?,SYSDATE)";
public static final String SELECT_QUERY="SELECT Patient_Id_Seq.CURRVAL from dual";
}
