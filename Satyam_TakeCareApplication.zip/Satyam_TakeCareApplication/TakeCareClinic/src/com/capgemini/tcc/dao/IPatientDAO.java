package com.capgemini.tcc.dao;
/*
 * author by Satyam
 * Last modified on 17 Aug 2018
 * */
import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.PatientException;

public interface IPatientDAO {
	public abstract int addPatientDetails(PatientBean patient) throws PatientException;
}
