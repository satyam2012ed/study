package com.capgemini.tcc.bean;
/*
 * author by Satyam
 * Last modified on 17 Aug 2018
 * */
public class PatientBean {
	private String patient_name;
	private int patient_age;
	private String patient_phone;
	private String description;

	public String getPatient_name() {
		return patient_name;
	}

	public void setPatient_name(String patient_name) {
		this.patient_name = patient_name;
	}

	public int getPatient_age() {
		return patient_age;
	}

	public void setPatient_age(int patient_age) {
		this.patient_age = patient_age;
	}

	public String getPatient_phone() {
		return patient_phone;
	}

	public void setPatient_phone(String patient_phone) {
		this.patient_phone = patient_phone;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public PatientBean(String patient_name, int patient_age,
			String patient_phone, String description) {
		this.patient_name = patient_name;
		this.patient_age = patient_age;
		this.patient_phone = patient_phone;
		this.description = description;
	}

	public PatientBean() {
	}

}
