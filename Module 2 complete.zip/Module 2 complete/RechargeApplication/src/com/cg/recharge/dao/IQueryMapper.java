package com.cg.recharge.dao;

public class IQueryMapper {
	public static final String INSERT_QUERY="INSERT INTO RechargeDetails values(rech_seq.NEXTVAL,?,?,?,?,SYSDATE)";
	public static final String VIEW_SEQ="SELECT rech_seq.currval from dual";
}
