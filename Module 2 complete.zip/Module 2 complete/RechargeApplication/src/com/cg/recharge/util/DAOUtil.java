package com.cg.recharge.util;

import java.sql.*;

public class DAOUtil {
static Connection conn=null;
	
	public static Connection establishConnection() throws SQLException {
		
			conn = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg218","training218");
		return conn;
	}
}
