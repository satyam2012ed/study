package com.capgemini.tcc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

//import com.cg.rechargeapplication.bean.RechargeBean;
//import com.cg.rechargeapplication.dao.DBUtil;
//import com.cg.rechargeapplication.exception.RechargeException;

import org.apache.log4j.Logger;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.PatientException;

/*
 * author by Satyam
 * Last modified on 17 Aug 2018
 * */
public class PatientDAO implements IPatientDAO, IQueryMapper {
	static Logger log = Logger.getRootLogger();

	/*
	 * This method is used to add into Patient table Patient Id is auto
	 * generated using a sequence Consultant date is input as current date It
	 * returns Patient ID after inserting into the table
	 */
	@Override
	public int addPatientDetails(PatientBean patient) throws PatientException {
		// TODO Auto-generated method stub
		Connection conn = DBUtil.getConnection();
		int n = 0;
		int current_patient_id = 0;
		try {
			PreparedStatement pstmt = conn.prepareStatement(INSERT_QUERY);
			pstmt.setString(1, patient.getPatient_name());
			pstmt.setInt(2, patient.getPatient_age());
			pstmt.setString(3, patient.getPatient_phone());
			pstmt.setString(4, patient.getDescription());
			n = pstmt.executeUpdate();
			if (n == 1) {
				log.info("1 record inserted!!");
				PreparedStatement pstmt1 = conn.prepareStatement(SELECT_QUERY);
				ResultSet rs = pstmt1.executeQuery();
				rs.next();
				current_patient_id = rs.getInt(1);

			}

		} catch (SQLException e1) {
			log.error("Error occured!!" + e1.getMessage());
			throw new PatientException("Error occured!!" + e1.getMessage());

		} finally {
			if (conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return current_patient_id;
	}
	
}
