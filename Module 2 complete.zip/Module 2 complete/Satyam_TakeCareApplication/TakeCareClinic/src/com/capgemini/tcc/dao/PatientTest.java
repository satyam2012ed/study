package com.capgemini.tcc.dao;
/*
 * author by Satyam
 * Last modified on 17 Aug 2018
 * */
import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.PatientException;

public class PatientTest {
IPatientDAO dao=null;
	@Test
	public void testAddPatientDetails() throws PatientException {
		dao=new PatientDAO();
		PatientBean patient=new PatientBean("Test",1,"9999999999","TestDescription");
		assertEquals(1013, dao.addPatientDetails(patient));
	}
	@Test
	public void testAddPatientDetails1() throws PatientException {
		dao=new PatientDAO();
		PatientBean patient=new PatientBean("Test",1,"9999999999","TestDescription");
		assertEquals(1000, dao.addPatientDetails(patient));
	}
}
