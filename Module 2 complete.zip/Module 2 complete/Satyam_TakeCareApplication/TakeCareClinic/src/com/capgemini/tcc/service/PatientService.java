package com.capgemini.tcc.service;

/*
 * author by Satyam
 * Last modified on 17 Aug 2018
 * */
import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.IPatientDAO;
import com.capgemini.tcc.dao.PatientDAO;
import com.capgemini.tcc.exception.PatientException;

public class PatientService implements IPatientService {
	IPatientDAO dao = null;

	/*
	 * This method receives Patient object from client interface and passes it
	 * to DAO layer to be inserted into database
	 */
	@Override
	public int addPatientDetails(PatientBean patient) throws PatientException {
		dao = new PatientDAO();

		return dao.addPatientDetails(patient);
	}
	public void Patient() throws PatientException{
		throw new PatientException();
	}
}
