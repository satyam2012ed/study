package com.capgemini.tcc.ui;

/*
 * author by Satyam
 * Last modified on 17 Aug 2018
 * */
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.PatientException;
import com.capgemini.tcc.service.IPatientService;
import com.capgemini.tcc.service.PatientService;

public class Client {
	static Logger log = Logger.getRootLogger();

	public static void main(String[] args) throws PatientException {
		Scanner scanner = new Scanner(System.in);
		System.out.println("*******************************");
		System.out.println("--TakeCare Clinic Application--");
		System.out.println("*******************************");
		System.out.println();
		System.out.println("1.Add Patient Information");
		System.out.println("2.Exit");
		System.out.println();
		System.out.println("Enter your choice:");
		int choice = scanner.nextInt();
		switch (choice) {
		case 1:
			System.out.println("Enter the name of the Patient:");
			String name = scanner.next();
			System.out.println("Enter Patient Age:");
			int age = scanner.nextInt();
			System.out.println("Enter Patient phone number:");
			String phone = scanner.next();
			System.out.println("Enter Description:");
			String description = scanner.next();
			PatientBean patient = new PatientBean(name, age, phone, description);
			addPatient(patient);
			break;
		case 2:
			System.out.println("Thank You!!");
			log.error("Program terminated without inserting any record");
			System.exit(0);
		default:
			System.out.println("Wrong choice entered");
			log.error("Wrong Choice!! Program terminated");
			break;

		}
		scanner.close();
	}

	/*
	 * This method passes the Patient object to the service layer to be inserted
	 * into the database
	 */
	public static void addPatient(PatientBean patient) throws PatientException {
		IPatientService service = null;
		service = new PatientService();
		int current_patient_id = service.addPatientDetails(patient);
		if (current_patient_id == 0) {
			System.err.println("Recharge not done!!");
			log.error("error");
		} else {
			log.info("Patient Information stored successfully for Patient ID "
					+ current_patient_id);
			System.out
					.println("Patient Information stored successfully for Patient ID "
							+ current_patient_id);
		}

	}

}
