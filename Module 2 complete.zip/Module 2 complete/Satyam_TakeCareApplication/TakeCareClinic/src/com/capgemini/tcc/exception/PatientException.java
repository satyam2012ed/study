package com.capgemini.tcc.exception;
/*
 * author by Satyam
 * Last modified on 17 Aug 2018
 * */
public class PatientException extends Exception {
	private static final long serialVersionUID = 1L;

	public PatientException()
	{
	
	}
	public PatientException(String message) {
		super(message);
	}

}
