package com.dthoperator.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.dthoperator.exception.RechargeException;

public class RechargeDataValidator {
	/*
	 * To validate DTH operator
	 */
	public boolean validatedthOperator(String dthOperator)
			throws RechargeException {
		Matcher m = null;
		String word[] = { "Airtel", "DishTV", "Reliance", "TATASky" };

		for (int i = 0; i < word.length; i++) {
			Pattern p = Pattern.compile(word[i]);
			m = p.matcher(dthOperator);
			if (m.matches() == true) {
				break;
			}
		}
		if (m.matches() == false) {
			System.err
					.println("Operator should be Airtel/DishTV/Reliance/TATASky");

		}
		return m.matches();

	}

	/*
	 * To validate Consumer no
	 */
	public boolean validateConsumerNo(String consumerNo)
			throws RechargeException {
		Matcher m = null;
		Pattern p = Pattern.compile("[0-9]{10}");
		m = p.matcher(consumerNo);
		if (m.matches() == false) {
			System.err.println("Consumer no should be of 10 digits only");
		}
		return m.matches();

	}

	/*
	 * To validate recharge plan
	 */
	public boolean validatePlan(String plan) throws RechargeException {
		String word[] = { "Monthly", "Quarterly", "Half yearly", "Annual" };
		Matcher m = null;
		for (int i = 0; i < word.length; i++) {
			Pattern p = Pattern.compile(word[i]);
			m = p.matcher(plan);
			if (m.matches() == true) {
				break;
			}

		}
		if (m.matches() == false) {
			System.err
					.println("Plan should be Monthly/Quarterly/Half yearly/Annual");
		}
		return m.matches();
	}

	/*
	 * To validate amount
	 */
	public boolean validateAmount(String amount) throws RechargeException {
		Matcher m = null;
		Pattern p = Pattern.compile("[0-9]{3,4}");

		m = p.matcher(amount);
		if (m.matches() == false) {
			System.err
					.println("Amount should be of minimum 3 digits and maximum of 4 digits");
		}
		return m.matches();

	}
}
