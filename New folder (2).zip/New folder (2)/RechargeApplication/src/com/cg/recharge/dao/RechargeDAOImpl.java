package com.cg.recharge.dao;
import java.sql.*;

import com.cg.recharge.bean.*;
import com.cg.recharge.exception.*;
import com.cg.recharge.util.*;
public class RechargeDAOImpl implements IRechargeDAO {
	private Connection conn=null;
	@Override
	public boolean addRechargeDetails(RechargeBean recharge) throws RechargeProblemException {
		boolean status=false;
		try {
			conn=DAOUtil.establishConnection();
			PreparedStatement preparedStatement=conn.prepareStatement(IQueryMapper.INSERT_QUERY);
			preparedStatement.setString(1, recharge.getName());
			preparedStatement.setLong(2, recharge.getMobile());
			preparedStatement.setDouble(3, recharge.getAmount());
			preparedStatement.setString(4, recharge.getPlan());
			
			int storedStatus=preparedStatement.executeUpdate();
			
			if(storedStatus==1){
				
				status=true;
			}
			Statement stmt = conn.createStatement(); 
			ResultSet rs=stmt.executeQuery(IQueryMapper.VIEW_SEQ); 
			while(rs.next()){  
		         recharge.setRid(rs.getInt(1));
		         System.out.println(rs.getInt(1));
			}
		}  catch (SQLException e) {
			throw new RechargeProblemException("problem : "+e.getMessage());
		}
		return status;
	}
}
