package com.cg.recharge.dao;

import com.cg.recharge.bean.*;
import com.cg.recharge.exception.*;
public interface IRechargeDAO {
	public abstract boolean addRechargeDetails(RechargeBean recharge) throws RechargeProblemException;
}