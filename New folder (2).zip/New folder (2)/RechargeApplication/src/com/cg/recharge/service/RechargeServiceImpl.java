package com.cg.recharge.service;

import com.cg.recharge.bean.RechargeBean;
import com.cg.recharge.dao.*;
import com.cg.recharge.exception.RechargeProblemException;

public class RechargeServiceImpl implements IRechargeService{

	IRechargeDAO recDao=null;
	@Override
	public boolean addRechargeDetails(RechargeBean recharge) throws RechargeProblemException {
		recDao=new RechargeDAOImpl();
		
		return recDao.addRechargeDetails(recharge);
	}

}