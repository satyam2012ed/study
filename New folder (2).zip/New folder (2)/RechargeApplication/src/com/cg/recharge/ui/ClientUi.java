package com.cg.recharge.ui;

import java.util.Scanner;

import org.apache.log4j.Logger;

import com.cg.recharge.bean.*;
import com.cg.recharge.exception.*;
import com.cg.recharge.service.*;

public class ClientUi {
	static Logger log=Logger.getRootLogger();
	public static void main(String[] args) {
		System.out.println("---Recharge Portal----");
		System.out.println();
		System.out.println("1. Add recharge details");
		System.out.println("2. Exit");
		System.out.println();
		System.out.println("enter option :");
		Scanner scanner=new Scanner(System.in);
		int option=scanner.nextInt();
		RechargeBean recharge=new RechargeBean();
		switch(option){
		case 1:
			System.out.println("Enter name ");
			String name=scanner.next();
			System.out.println("Enter amount ");
			Double amount=scanner.nextDouble();
			System.out.println("Enter mobile ");
			Long mobile=scanner.nextLong();
			System.out.println("Enter Recharge Plan");
			System.out.println("1. rc99");
			System.out.println("2. rc200");
			System.out.println("3. rc400");
			option = scanner.nextInt();
			switch(option){
			case 1:
				recharge.setPlan("rc99");
				break;
			case 2:
				recharge.setPlan("rc200");
				break;
			case 3:
				recharge.setPlan("rc200");
				break;
			default:
				System.out.println("Wrong option entered");
			}
			recharge.setAmount(amount);
			recharge.setName(name);
			recharge.setMobile(mobile);
			scanner.close();
			try {
				boolean status=new ClientUi().addrecharge(recharge);
				if(status == true){
					log.info("Recharge Successful!!");
					System.out.println("Your mobile number "+recharge.getMobile()+" is recharged with "+recharge.getPlan()+" and id is "+recharge.getRid());
				}
				else {
					log.error("Recharge Unsuccessful!!");
				}
			} catch (RechargeProblemException e) {
				System.err.println("exception: "+e.getMessage());
			}
			break;
		case 2:
			System.out.println("Exiting...");
			System.exit(0);
		default:
				System.out.println("Wrong option entered");
		}
	}

	IRechargeService recServ=null;
	public boolean addrecharge(RechargeBean recharge) throws RechargeProblemException{
		recServ=new RechargeServiceImpl();
		return recServ.addRechargeDetails(recharge);
	}
	
}
