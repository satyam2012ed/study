package com.cg.recharge.exception;

public class RechargeProblemException extends Exception{
	public RechargeProblemException(String message) {
		super(message);
	}
	public RechargeProblemException(){
		
	}
}
