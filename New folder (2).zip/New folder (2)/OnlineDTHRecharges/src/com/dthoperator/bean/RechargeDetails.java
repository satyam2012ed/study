/*******Author Name:Md. Rawoof Ahmed Emp Id : 150936 Date: 5.7.2018 ******/
//Purpose: To provide getters and setters for recharges details

package com.dthoperator.bean;

//initializing instance variables
public class RechargeDetails {
	private String dthOperator;
	private int consumerNo;
	private String rechargePlan;
	private int amount;
	private int transactionID;

	
	//default constructor
	public RechargeDetails() {
	}

	//getter for DTH operator
	public String getDthOperator() {
		return dthOperator;
	}

	
	//setter for DTH operator
	public void setDthOperator(String dthOperator) {
		this.dthOperator = dthOperator;
	}

	
	//getter for Consumer Number
	public int getConsumerNo() {
		return consumerNo;
	}

	//setter for Consumer Number
	public void setConsumerNo(int consumerNo) {
		this.consumerNo = consumerNo;
	}

	
	//getter for Recharge plan
	public String getRechargePlan() {
		return rechargePlan;
	}

	//setter for Recharge plan
	public void setRechargePlan(String rechargePlan) {
		this.rechargePlan = rechargePlan;
	}

	//getter for Amount
	public int getAmount() {
		return amount;
	}

	//setter for Amount
	public void setAmount(int amount) {
		this.amount = amount;
	}

	//getter for Transaction ID
	public int getTransactionID() {
		return transactionID;
	}

	//setter for Transaction ID
	public void setTransactionID(int transactionID) {
		this.transactionID = transactionID;
	}

	public RechargeDetails(String dthOperator, int consumerNo,
			String rechargePlan, int amount, int transactionID) {

		this.dthOperator = dthOperator;
		this.consumerNo = consumerNo;
		this.rechargePlan = rechargePlan;
		this.amount = amount;
		this.transactionID = transactionID;
	}

	//displaying recharges details 
	@Override
	public String toString() {
		return "RechargeDetails [dthOperator=" + dthOperator + ", consumerNo="
				+ consumerNo + ", rechargePlan=" + rechargePlan + ", amount="
				+ amount + ", transactionID=" + transactionID + "]";
	}
}
