

package com.dthoperator.ui;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import com.dthoperator.bean.RechargeDetails;
import com.dthoperator.exception.RechargeException;
import com.dthoperator.service.RechargeCollectionHelper;
import com.dthoperator.service.RechargeDataValidator;

public class RechargeClient {

	public static void main(String[] args) {

		try {
			RechargeCollectionHelper collectionHelper = new RechargeCollectionHelper();
			RechargeDataValidator dataValidator = new RechargeDataValidator();
			ArrayList<RechargeDetails> list = new ArrayList<>();
			Scanner scanner = new Scanner(System.in);
			int option;
			do {
				RechargeDetails rechargeDetails = new RechargeDetails();
				System.out
						.println("1. Make a Recharge.\n2. Display Recharge Details.\n3. Exit");
				option = scanner.nextInt();
				switch (option) {
				case 1:
					/*
					 * To select DTH Operator - it should be Airtel/DishTV/Reliance/TATASky
					 */
					System.out
							.println("Select DTH Operator(Airtel/DishTV/Reliance/TATASky)");
					String dthOperator = scanner.next();

					while (!dataValidator.validatedthOperator(dthOperator)) {

						System.out
								.println("Select DTH Operator(Airtel/DishTV/Reliance/TATASky)");
						dthOperator = scanner.next();
					}
					rechargeDetails.setDthOperator(dthOperator);

					/*
					 *  To enter the valid consumer number - it should be 10 digits
					 */
					System.out.println("Enter Registered Consumer No.:");
					String conNum;
					conNum = scanner.next();

					while (!dataValidator.validateConsumerNo(conNum)) {
						System.out.println("Enter Registered Consumer No.:");
						conNum = scanner.next();
					}

					rechargeDetails.setConsumerNo(Integer.parseInt(conNum));
					/*
					 *  To select a recharge plan - is should be Monthly/Quarterly/Half yearly/Annual
					 */
					System.out
							.println("Select Plan(Monthly/Quarterly/Half yearly/Annual)");
					String rechargePlan;
					Scanner scanner2 = new Scanner(System.in);
					rechargePlan = scanner2.nextLine();
					while (!dataValidator.validatePlan(rechargePlan)) {

						System.out
								.println("Select Plan(Monthly/Quarterly/Half yearly/Annual)");
						Scanner scanner3 = new Scanner(System.in);
						rechargePlan = scanner3.nextLine();
					}
					rechargeDetails.setRechargePlan(rechargePlan);

					/*
					 * To enter the valid amount it should be 3 or 4 digits
					 */
					System.out.println("Enter Amount (Rs.):");
					String amount;
					Scanner scanner4 = new Scanner(System.in);
					amount = scanner4.next();
					while (!dataValidator.validateAmount(amount)) {
						System.out.println("Enter Amount (Rs.):");
						amount = scanner4.next();
					}
					rechargeDetails.setAmount(Integer.parseInt(amount));

					/*
					 * To generate random transaction id it should be 4 digits
					 */
					Random random = new Random();
				
					int transactionID = Math.abs(random.nextInt(10000));
					rechargeDetails.setTransactionID(transactionID);
					collectionHelper.addRechargeDetails(rechargeDetails);
					System.out.println("Successful Recharge. Transaction ID :"
							+ transactionID);
					break;

				case 2:
					/*
					 * To display the details 
					 */
					System.out.println("Enter transaction Id to display recharge details");
					
					
					
					Scanner scanner3 = new Scanner(System.in);
					int id = scanner3.nextInt();
					collectionHelper.displayRechargeDetails(id);

					break; 

				case 3:
					/*
					 * To exit from the application
					 */
					System.out.println("You have exited from the Online Recharge application");
					System.exit(0);
					break;

				default:
					/*
					 * If user selects a wrong option
					 */
					System.out.println("Wrong Choice\n");
					break;
				}
			} while (option != 3);
		} catch (RechargeException exception) {
			/*
			 * To handle exception
			 */
			System.err.println("Failed to Recharge.");
		}

	}

}
