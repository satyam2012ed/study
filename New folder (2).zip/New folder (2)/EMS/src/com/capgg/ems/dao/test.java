package com.capgg.ems.dao;

import java.sql.Connection;

public class test {

	public static void main(String[] args) {
		
		System.out.println("Hello");
		
	}

}
