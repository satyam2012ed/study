package com.capgemini.tcc.ui;

public class PatientBean {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
