package com.capgemini.tcc.exception;

public class PatientException extends Exception {

	public PatientException(String Message)
	{
		super(Message);
	}
}
