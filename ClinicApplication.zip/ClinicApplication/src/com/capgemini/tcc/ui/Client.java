package com.capgemini.tcc.ui;

import java.sql.Date;
import java.util.Scanner;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.PatientException;
import com.capgemini.tcc.service.IPatientService;
import com.capgemini.tcc.service.PatientService;

public class Client {
	
	static String patient_name;
	static int age;
	static String phone;
	static String description;
	
	static IPatientService patientservice = new PatientService();
	
	public static void main(String[] args) throws PatientException
	{
		Scanner scanner = new Scanner(System.in);
		char ch;
		int option;
		int count=0;
		
			System.out.println("Select from Menu:-");
			System.out.println("1. Add Patient Information");
			System.out.println("2. Exit");
			System.out.println("Enter the choice");
			option=scanner.nextInt();

			switch(option)
			{
				case 1: //System.out.println("Patient ID is automatically generated:");
						System.out.println("Enter the name of the Patient:");
						patient_name = scanner.next();
						System.out.println("Enter Patient Age:");
						age = scanner.nextInt();
						System.out.println("Enter Patient phone number:");
						phone = scanner.next();
						System.out.println("Enter Description:");
						description = scanner.next();
						
						PatientBean patient = new PatientBean(patient_name,age,phone,description);
						int pid = patientservice.addPatientDetails(patient);
						System.out.println("Id is"+pid);
						break;
						
				case 2: break;
			}
	}
	

}
