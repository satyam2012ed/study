package com.capgemini.tcc.dbutil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.capgemini.tcc.exception.PatientException;


public class DBUtil {
	public static Connection getConnection() throws PatientException {
		Connection conn = null;
		try {
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			conn = DriverManager.getConnection(
					"jdbc:oracle:thin:@10.219.34.3:1521:orcl", "trg229",
					"training229");

		} catch (SQLException e) {
			throw new PatientException("Error occured!!"+e.getMessage());
		}
		return conn;
	}
}