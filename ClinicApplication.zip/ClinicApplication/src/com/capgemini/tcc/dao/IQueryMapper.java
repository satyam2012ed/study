package com.capgemini.tcc.dao;

public interface IQueryMapper {

	public final String Patient_insert_query = "INSERT INTO PATIENT VALUES(PATIENT_ID_SEQ.NEXTVAL, ?, ?, ?, ?, SYSDATE)";
	public final String Patient_id_query_sequence = " select patient_id_seq.currval from dual";
}
