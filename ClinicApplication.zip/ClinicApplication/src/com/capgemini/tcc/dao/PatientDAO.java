package com.capgemini.tcc.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dbutil.DBUtil;
import com.capgemini.tcc.exception.PatientException;

public class PatientDAO implements IPatientDAO {

	static Logger logger = Logger.getLogger("logfile");
	Connection connection = null;

	@Override
	public int addPatientDetails(PatientBean patient) throws PatientException
	{
		Connection conn = DBUtil.getConnection();
		int status=0;
		int current_patient_id=0;
		try
		{
			PreparedStatement pstmt = conn.prepareStatement(IQueryMapper.Patient_insert_query);
			pstmt.setString(1, patient.getPatient_name());
			pstmt.setLong(2, patient.getAge());
			pstmt.setString(3, patient.getPhone());
			pstmt.setString(4, patient.getDescription());
			
			status =pstmt.executeUpdate();
			
			if(status==1)
			{
				System.out.println("inserted");
				PreparedStatement pstmt1 = conn.prepareStatement(IQueryMapper.Patient_id_query_sequence);
				ResultSet rs = pstmt1.executeQuery();
				rs.next();
				current_patient_id = rs.getInt(1);
			}
			
		} catch(SQLException sql)
		{
			logger.error("data not inserted");
			throw new PatientException("database not stored value"+sql.getMessage());			
		}
		return current_patient_id;
	}
}

