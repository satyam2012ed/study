package com.capgemini.tcc.service;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.IPatientDAO;
import com.capgemini.tcc.dao.PatientDAO;
import com.capgemini.tcc.exception.PatientException;

public class PatientService implements IPatientService {
	IPatientDAO patientDAO = null;
	
	public int addPatientDetails(PatientBean patient) throws PatientException {
		IPatientDAO patientDAO =new PatientDAO();
		int patient_id =patientDAO.addPatientDetails(patient);
		
		return patient_id;	
		
	}
}
